from __future__ import print_function
import argparse
import torch
from torch.autograd import Variable
import numpy as np
import time
import scipy.io as sio
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

start = time.time()

# Test settings
parser = argparse.ArgumentParser(description='PyTorch Super Res Example')
parser.add_argument('--model', type=str, required=True, help='model file to use')
parser.add_argument('--cuda', action='store_true', help='use cuda')
opt = parser.parse_args()

print(opt)

model = torch.load(opt.model)

if opt.cuda:
    model = model.cuda()

root_path = "./normal_rat_kidney/"

dir = root_path
for root,dir,files in os.walk(dir):  
    for file in files:  
        img = sio.loadmat(root_path+str(file))
        img = np.array(img['I1'])
        img = img.reshape([img.shape[1],img.shape[0],1])

        input = Variable(torch.tensor(img).float()).view(1, -1, img.shape[1], img.shape[0])

        if opt.cuda:
            input = input.cuda()

        out = model(input)
        out = out.cpu()
        out_img = out.data[0].numpy()
        out_img = out_img.reshape(img.shape[1] * 4, img.shape[0] * 4)
        sio.savemat('normal_rat_kidney_re/'+str(file), {'reconstruction':out_img})
        print('output image saved to ','normal_rat_kidney_re/'+str(file))
  

end = time.time()

print (end-start)

